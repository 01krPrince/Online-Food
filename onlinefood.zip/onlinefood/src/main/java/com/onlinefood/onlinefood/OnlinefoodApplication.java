package com.onlinefood.onlinefood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinefoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinefoodApplication.class, args);
	}

}
