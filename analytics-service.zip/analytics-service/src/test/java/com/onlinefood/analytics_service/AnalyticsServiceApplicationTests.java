package com.onlinefood.analytics_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalyticsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
